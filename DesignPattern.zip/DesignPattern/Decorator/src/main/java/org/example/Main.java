package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Coffee coffee = new SimpleCoffee();  // Simple Coffee
        System.out.println(coffee.getDescription() + " ₹" + coffee.getCost());

        coffee = new MilkDecorator(coffee);  // Milk add kiya
        System.out.println(coffee.getDescription() + " ₹" + coffee.getCost());

        coffee = new SugarDecorator(coffee);  // Sugar add kiya
        System.out.println(coffee.getDescription() + " ₹" + coffee.getCost());
    }
}