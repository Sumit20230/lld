package org.example;

public interface Coffee {
    double getCost();  // coffee ki cost return karega
    String getDescription();  // coffee ki description return karega
}
