package org.example;

public class SimpleCoffee implements Coffee {
    @Override
    public double getCost() {
        return 50;  // Basic coffee ki cost
    }

    @Override
    public String getDescription() {
        return "Simple Coffee";
    }
}
