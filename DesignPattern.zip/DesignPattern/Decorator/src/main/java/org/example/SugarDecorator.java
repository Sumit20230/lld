package org.example;

public class SugarDecorator extends CoffeeDecorator {
    public SugarDecorator(Coffee coffee) {
        super(coffee);
    }

    @Override
    public double getCost() {
        return super.getCost() + 5;  // Sugar ka extra cost
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", Sugar";
    }
}
