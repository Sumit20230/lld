package org.example;

public class SMARTTV implements TV{
    public void on(){
        System.out.println("SMART TV  on");
    }
    public   void off(){
        System.out.println("SMART TV  off");
    }
    public void changeChannel(int channel){
        System.out.println("channel is set at" +channel);
    }
}
