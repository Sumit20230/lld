package org.example;

abstract  class Remote {
    protected TV tv;

    public Remote(TV tv) {
        this.tv = tv;
    }

    abstract void powerButton();
    abstract void changeChannelButton(int channel);
}
