package org.example;

public class AdvanceRemote extends Remote{


    public AdvanceRemote(TV tv) {
        super(tv);
    }

    public void powerButton() {
        System.out.println("Advanced Remote: Power button press kiya");
        tv.on();
    }

    public void changeChannelButton(int channel) {
        System.out.println("Advanced Remote: Channel change karna hai " + channel);
        tv.changeChannel(channel);
    }

    public void setFavoriteChannel(int channel) {
        System.out.println("Advanced Remote: Favorite channel set kiya " + channel);
        tv.changeChannel(channel);
    }
}
