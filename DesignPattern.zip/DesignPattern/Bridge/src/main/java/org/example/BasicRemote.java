package org.example;

public class BasicRemote extends Remote {
    public BasicRemote(TV tv) {
        super(tv);
    }

    public void powerButton() {
        System.out.println("Basic Remote: Power button press kiya");
        tv.on();
    }

    public void changeChannelButton(int channel) {
        System.out.println("Basic Remote: Channel change karna hai " + channel);
        tv.changeChannel(channel);
    }
}
