package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        TV ledTV = new LEDTV();
        Remote basicRemote = new BasicRemote(ledTV);
        basicRemote.powerButton();
        basicRemote.changeChannelButton(10);

        TV smartTV = new SMARTTV();
        Remote advancedRemote = new AdvanceRemote(smartTV);
        advancedRemote.powerButton();
        advancedRemote.changeChannelButton(5);
        ((AdvanceRemote) advancedRemote).setFavoriteChannel(5);
    }
}