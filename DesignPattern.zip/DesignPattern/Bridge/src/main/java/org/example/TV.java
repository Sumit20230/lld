package org.example;

public interface TV {
    void on();
    void off();
    void changeChannel(int channel);
}
