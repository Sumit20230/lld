package org.example;

public class LEDTV implements TV{
   public void on(){
        System.out.println("LEDTV  on");
    }
  public   void off(){
      System.out.println("LEDTV  off");
    }
   public void changeChannel(int channel){
       System.out.println("channel is set at" +channel);
    }
}
