package org.example;

// Strategy Interface
interface TextFormatter {
    String format(String text);
}
