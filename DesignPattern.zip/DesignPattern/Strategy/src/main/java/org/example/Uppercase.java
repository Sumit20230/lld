package org.example;

public class Uppercase implements  TextFormatter{
    @Override
    public String format(String text) {

        return text.toUpperCase();
    }

}
