package org.example;

// Context Class
class TextEditor {
    private TextFormatter formatter;

    public void setFormatter(TextFormatter formatter) {
        this.formatter = formatter;
    }

    public void displayFormattedText(String text) {
        System.out.println(formatter.format(text));
    }
}
