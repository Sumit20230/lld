package org.example;

public class LowerCase  implements  TextFormatter{


    @Override
    public String format(String text) {
        return  text.toLowerCase();
    }
}
