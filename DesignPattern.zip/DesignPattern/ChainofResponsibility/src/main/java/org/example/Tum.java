package org.example;

public class Tum extends FamilyMember {
    @Override
    public void handleRequest(String request) {
        if (request.equals("chai")) {
            System.out.println("Tum: Main busy hoon ya mujhe chai banani nahi aati, request mummy ko forward kar raha hoon.");
            if (nextMember != null) {
                nextMember.handleRequest(request);
            }
        }
    }
}

