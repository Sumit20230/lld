package org.example;
public class Mummy extends FamilyMember {
    @Override
    public void handleRequest(String request) {
        if (request.equals("chai")) {
            System.out.println("Mummy: Main chai bana rahi hoon aur abhi serve kar rahi hoon.");
        }
    }
}
