package org.example;

public abstract class FamilyMember {
    protected FamilyMember nextMember;

    public void setNextMember(FamilyMember nextMember) {
        this.nextMember = nextMember;
    }

    public abstract void handleRequest(String request);
}

