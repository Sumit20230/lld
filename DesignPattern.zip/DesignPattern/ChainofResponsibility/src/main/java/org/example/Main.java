package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
// Chain setup
        FamilyMember chhotaBhai = new ChhotaBhai();
        FamilyMember tum = new Tum();
        FamilyMember mummy = new Mummy();

        chhotaBhai.setNextMember(tum);
        tum.setNextMember(mummy);

        // Request handling
        chhotaBhai.handleRequest("chai");
    }
}