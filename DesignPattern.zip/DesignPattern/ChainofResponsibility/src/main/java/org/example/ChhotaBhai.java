package org.example;

public class ChhotaBhai extends FamilyMember {
    @Override
    public void handleRequest(String request) {
        if (request.equals("chai")) {
            System.out.println("Chhota Bhai: Mujhe chai banani nahi aati, main request forward kar raha hoon.");
            if (nextMember != null) {
                nextMember.handleRequest(request);
            }
        }
    }
}

