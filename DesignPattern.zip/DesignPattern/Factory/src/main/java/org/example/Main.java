package org.example;


public class Main {
    public static void main(String[] args) {
       DrinkFactory drinkFactory= new DrinkFactory();
       Drink obj=drinkFactory.select("Tea");
      obj.prepare();
    }
}