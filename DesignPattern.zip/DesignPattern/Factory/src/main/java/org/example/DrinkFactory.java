package org.example;

public class DrinkFactory {

    public static Drink select(String type)
    {
        if(type.equalsIgnoreCase("Coffee"))
            return new Coffee();
        if(type.equalsIgnoreCase("Tea"))
            return new Tea();
        return  null;
    }
}
