package org.example;

public class Tea implements Drink{
  public   void prepare()
    {
        System.out.println("Tea is ready");
    }
}
