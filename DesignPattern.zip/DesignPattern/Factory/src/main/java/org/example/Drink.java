package org.example;

public interface Drink {
    void prepare();
}
