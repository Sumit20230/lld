package org.example;

public class Coffee implements Drink{
    public void prepare()
    {
        System.out.println("Coffee is ready");
    }
}
