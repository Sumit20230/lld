package org.example;

public class priceVisitor implements  Visitor {
    @Override
    public void visit(Books book) {
        System.out.println("Book price: " + book.getPrice());
    }


    @Override
    public void visit(Magazine magazine) {
        System.out.println("Magazine price: " + magazine.getPrice());
    }
}
