package org.example;

public interface Visitor {
    void visit(Books book);



    void visit(Magazine magazine);
}
