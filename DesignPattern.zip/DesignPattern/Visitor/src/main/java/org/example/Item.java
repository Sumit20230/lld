package org.example;

public interface Item {
    void accept(Visitor visitor);
}
