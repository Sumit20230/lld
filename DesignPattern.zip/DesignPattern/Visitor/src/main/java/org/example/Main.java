package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Item book = new Books("Java Programming", 29.99);
        Item magazine = new Magazine("Tech Today", 5.99);
        Visitor priceVisitor = new priceVisitor();
        Visitor printVisitor = new printVisitor();
        book.accept(priceVisitor);  // Prints the price of the book
        book.accept(printVisitor);  // Prints the title of the book

        magazine.accept(priceVisitor);  // Prints the price of the magazine
        magazine.accept(printVisitor);
    }
}