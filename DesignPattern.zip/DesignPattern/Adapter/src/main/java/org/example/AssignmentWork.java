package org.example;

class AssignmentWork {
    private PenAdapter pen;

    public void setPen(PenAdapter pen) {
        this.pen = pen;
    }

    public void writeAssignment(String text) {
        pen.write(text); // System only knows about Pen's write() method
    }
}

