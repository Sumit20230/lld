package org.example;

class PenAdapter implements Pen {
    PilotPen pilotPen = new PilotPen(); // Adapter wraps PilotPen

    @Override
    public void write(String text) {
        pilotPen.writeSmooth(text); // Converts write() call to writeSmooth()
    }
}

