package org.example;

interface Pen {
    void write(String text);
}
