package org.example;
class PilotPen {
    public void writeSmooth(String text) {
        System.out.println("PilotPen is writing smoothly: " + text);
    }
}
