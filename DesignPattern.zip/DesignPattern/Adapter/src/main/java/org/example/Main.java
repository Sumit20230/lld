package org.example;



public class Main {
    public static void main(String[] args) {
        AssignmentWork assignment = new AssignmentWork();  // System
        PenAdapter penAdapter = new PenAdapter();          // Adapter

        assignment.setPen(penAdapter);  // Inject adapter
        assignment.writeAssignment("Adapter Design Pattern Example");
    }
}
