package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {//TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
TV tv= new TV();
Command powerOn= new PowerOnCommand(tv);
Command powerOff= new PowerofCommand(tv);
Command channelchange= new ChannelChangeCommand(tv,7);
RemoteControl remoteControl= new RemoteControl();
remoteControl.setCommand(powerOn);
remoteControl.pressButton();


        remoteControl.setCommand(powerOff);
        remoteControl.pressButton();


        remoteControl.setCommand(channelchange);
        remoteControl.pressButton();

    }
}