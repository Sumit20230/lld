package org.example;

public class PowerOnCommand implements Command{
    private  TV tv;
    private  int channel;
    PowerOnCommand(TV tv)
    {
        this.tv=tv;

    }
    @Override
    public void execute() {
       tv.powerOn();
    }
}
