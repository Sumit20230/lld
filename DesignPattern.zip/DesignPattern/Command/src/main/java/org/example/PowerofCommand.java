package org.example;

public class PowerofCommand implements Command{
    private  TV tv;

    PowerofCommand(TV tv)
    {
        this.tv=tv;
    }
    @Override
    public void execute() {
   tv.powerOff();
    }
}
