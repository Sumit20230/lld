package org.example;

public class ChannelChangeCommand implements Command{
    private  TV tv;
    private  int channel;
    ChannelChangeCommand(TV tv,int channel)
    {
        this.tv=tv;
        this.channel=channel;
    }

    @Override
    public void execute() {
        tv.channelChange(channel);
    }
}
