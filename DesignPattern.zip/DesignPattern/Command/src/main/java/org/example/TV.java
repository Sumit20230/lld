package org.example;

public class TV {
    void powerOn()
    {
        System.out.println("Tv on");
    }
    void powerOff()
    {
        System.out.println("Tv is off");
    }
    void channelChange(int channel)
    {
        System.out.println("channel is set at"+channel);
    }
}
