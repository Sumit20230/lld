package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("run");
        concreete c1=new concreete();
        c1.add("1");
        concreete c2=new concreete();
        c2.add("2");
        NewsAggency n= new NewsAggency();
        n.subcribes(c2);
        n.subcribes(c1);
        concreete c3=new concreete();
        c3.add("3");
        n.subcribes(c3);
        String news="hello world";
        n.publishNews(news);

    }
}