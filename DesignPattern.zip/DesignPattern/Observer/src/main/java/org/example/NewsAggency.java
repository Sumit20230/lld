package org.example;
import  java.util.ArrayList;
import java.util.List;

public class NewsAggency {
    List<Subsrciber>subsrcibers;
    void subcribes(Subsrciber newSubscriber)
    {
subsrcibers.add(newSubscriber);
    }
    void unsubsribes(Subsrciber removeSubscriber)
    {
        subsrcibers.remove(removeSubscriber);
    }
    void notify(String news)
    {
        int k=0;
        for(Subsrciber subsrciber:subsrcibers)
        {
            System.out.println(news+k);
            k++;
        }
    }
    void publishNews(String news)
    {
        notify(news);
    }

}
