package org.example;

public class concreete implements Subsrciber {
    String name;
    @Override
    public void add(String name) {
        this.name=name;
    }
}
