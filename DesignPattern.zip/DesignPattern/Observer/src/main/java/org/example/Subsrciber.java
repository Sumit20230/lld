package org.example;

public interface Subsrciber  {
    void add(String name);
}
