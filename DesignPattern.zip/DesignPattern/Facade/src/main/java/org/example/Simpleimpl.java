package org.example;

public class Simpleimpl {
    private ComplexCoffeeMachine complexCoffeeMachine;
    public  Simpleimpl(ComplexCoffeeMachine complexCoffeeMachine)
    {
        this.complexCoffeeMachine=complexCoffeeMachine;
    }
    void getCoffee()
    {
        complexCoffeeMachine.grindBeans();;
        complexCoffeeMachine.milkFeathering();;
        complexCoffeeMachine.mixing();
        System.out.println("coffee is ready\n");
    }
}
