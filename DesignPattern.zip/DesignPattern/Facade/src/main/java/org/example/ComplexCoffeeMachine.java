package org.example;

public class ComplexCoffeeMachine {
    public  void grindBeans()
    {
        System.out.println("beans are grinding");
    }
    public void milkFeathering()
    {
        System.out.println("milk is feathering");
    }
    public  void mixing()
    {
        System.out.println("all the things are mixing");
    }
}
