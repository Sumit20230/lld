package org.example;

import java.util.*;


public class Manager implements Employee{
    private String name,positions;
    public  Manager(String name,String positions)
    {
        this.name=name;
        this.positions=positions;
    }
    private List<Employee> subordinates = new ArrayList<>();
    public void add(Employee employee) {
        subordinates.add(employee);
    }
    @Override
    public void getDetails() {
   for(Employee emp:subordinates)
       emp.getDetails();
    }
}
