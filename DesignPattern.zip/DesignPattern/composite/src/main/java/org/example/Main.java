package org.example;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Employee engineer1 = new Engineer("John", "Engineer");
        Employee engineer2 = new Engineer("Mike", "Engineer");

        // Manager
        Manager manager1 = new Manager("Alice", "Manager");
        manager1.add(engineer1); // Manager managing engineer

        // Senior Manager
        Manager seniorManager = new Manager("Bob", "Senior Manager");
        seniorManager.add(manager1); // Senior manager managing manager
        seniorManager.add(engineer2); // Senior manager managing engineer directly

        // Show details of the whole hierarchy
        seniorManager.getDetails();
    }
}