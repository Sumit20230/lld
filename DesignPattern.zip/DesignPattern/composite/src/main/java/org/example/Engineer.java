package org.example;

public class Engineer implements Employee{
    private String name,position;
     public  Engineer(String name,String position)
     {
         this.name=name;
         this.position=position;

     }
    @Override
    public void getDetails() {
        System.out.println(name+" "+position);
    }
}
