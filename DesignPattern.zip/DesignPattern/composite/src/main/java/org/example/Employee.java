package org.example;

public interface Employee {
    void getDetails();
}
