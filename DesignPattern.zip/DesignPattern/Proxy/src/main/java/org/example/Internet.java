package org.example;

public interface Internet {
    void connectTo(String serverHost) throws Exception;
}

